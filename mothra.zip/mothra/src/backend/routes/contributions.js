const express = require("express");
const jwt = require("jsonwebtoken");
const { Contribution, Topic, User } = require("../models");
const {
  authAdminMiddleware,
  authTokenMiddleware,
} = require("../middlewares/auth");
const multer = require("multer");
const fs = require("fs");
const AdmZip = require("adm-zip");
const { ObjectId } = require("mongodb");

const router = express.Router();

const upload = multer({
  storage: multer.diskStorage({
    destination(req, file, cb) {
      cb(null, "./uploads");
    },
    filename(req, file, cb) {
      cb(null, `${new Date().getTime()}_${file.originalname}`);
    },
  }),
  limits: {
    fileSize: 1024 ** 2 * 10,
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpeg|jpg|png|pdf|doc|docx)$/)) {
      return cb(new Error("Unsupprted type file."));
    }
    cb(undefined, true); // continue with upload
  },
});

const checkContributionExists = (req, res, next) => {
  Contribution.findOne(req.body, (err, contribution) => {
    if (err) return next(err);
    if (contribution) {
      res
        .status(400)
        .json({ error: "That contribution is taken. Try another." });
    } else next();
  });
};

// Create new contribution
router.post(
  "/upload",
  upload.fields([
    { name: "articles", maxCount: 3 },
    { name: "images", maxCount: 10 },
  ]),
  authTokenMiddleware,
  checkContributionExists,
  async (req, res, next) => {
    const { role } = jwt.decode(req.token);    
    role === "student"
      ? next()
      : res.sendStatus(403);
  },
  async (req, res, next) => {
    const { topicId, title, author, abstract, articles, images } = req.body;    
    const topic = await Topic.findById(topicId);
    if (topic) {
      Contribution.create(
        {
          topicId,
          title,
          author,
          abstract,
          articles: req.files["articles"].map((x) => x.filename),
          images: req.files["images"].map((y) => y.filename),
        },
        (err, contribution) => {
          if (err) return next(err);
          res.status(201).json({ ...contribution.toJSON() });
        }
      );
    } else res.sendStatus(400);
  }
);

router
  .route("/:id")
  .get(authTokenMiddleware, async (req, res, next) => {
    const { role } = jwt.decode(req.token);
    if (["marketing coordinator", "student"].includes(role)) {
      Contribution.findById(req.params.id, (err, contribution) => {
        if (err) return next(err);
        res.status(200).json({ contribution });
      });
    } else res.sendStatus(403);
  })
  .put(
    authTokenMiddleware,
    (req, res, next) => {
      const { role } = jwt.decode(req.token);
      role === "student" ? next() : res.sendStatus(403);
    },
    (req, res, next) => {
      Contribution.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true, runValidators: true },
        (err, contribution) => {
          if (err) return next(err);
          res.status(200).json({ contribution });
        }
      );
    }
  )
  .delete(
    authTokenMiddleware,
    (req, res, next) => {
      const { role } = jwt.decode(req.token);
      role === "student" ? next() : res.sendStatus(403);
    },
    (req, res, next) => {
      Contribution.findByIdAndDelete(req.params.id, (err) => {
        if (err) return next(err);
        res.sendStatus(200);
      });
    }
  );

router.post("/:id/comments/", authTokenMiddleware, async (req, res) => {
  const { role } = jwt.decode(req.token);
  if (["student", "marketing coordinator"].includes(role)) {
    try {
      const user = await User.findById(req.token.id).select("-password");
      const contribution = await Contribution.findById(req.params.id);
      const newComment = {
        comment: req.body.comment,
        postedBy: req.token.id,
        createdAt: new Date().getTime(),
      };

      contribution.comments.unshift(newComment);

      await contribution.save();

      res.json(contribution.comments);
    } catch (error) {
      console.error(error.message);
      res.status(404);
    }
  }
});

router.delete(
  "/:id/comments/:commentId",
  authTokenMiddleware,
  async (req, res) => {
    const { role } = jwt.decode(req.token);
    if (["student", "marketing coordinator"].includes(role)) {
      try {
        const contribution = await Contribution.findById(req.params.id);
        // Check post exists
        if (!contribution) {
          return res.status(404).send("Post Not Found");
        }
        const comment = contribution.comments.find(
          (comment) => comment.id === req.params.comment_id
        );

        if (!comment) {
          return res.status(404).json({
            msg: "Comment not found",
          });
        }
        // Check post is user logged in
        if (comment.postedBy.toString() !== req.token.id) {
          return res.status(401);
        }

        const removeIndex = contribution.comments
          .map((comment) => comment.postedBy.toString())
          .indexOf(req.token.id);

        contribution.comments.splice(removeIndex, 1);

        await contribution.save();
        return res.json(contribution.comments);
      } catch (error) {
        console.error(error.message);
        if (error.kind == ObjectId) {
          return res.status(404);
        }
        res.status(500);
      }
    }
  }
);

router.get("/:id/download", authTokenMiddleware, async (req, res) => {
  const { role } = jwt.decode(req.token);
  const contribution = await Contribution.findById(req.params.id);
  const to_zip = fs.readdirSync("uploads");
  if (contribution && ["markerting manager"].includes(role)) {
    const zip = new AdmZip();
    for (var k = 0; k < to_zip.length; k++) {
      zip.addLocalFile("uploads" + "/" + to_zip[k]);
    }

    const downloadName = `downloadfile.zip`;
    const data = zip.toBuffer();

    zip.writeZip(downloadName);
    res.set("Content-Type", "application/octet-stream");
    res.set("Content-Disposition", `attachment; filename=${downloadName}`);
    res.set("Content-Length", data.length);
    res.send(data);
  }
});

router.use((err, req, res, next) => {
  res.status(400).json({ error: err.message });
});

module.exports = router;
