const express = require("express");
const jwt = require("jsonwebtoken");
const { User, Topic } = require("../models");
const {
  authAdminMiddleware,
  authTokenMiddleware,
} = require("../middlewares/auth");

const router = express.Router();

const checkTopicExists = (req, res, next) => {
  Topic.findOne(req.body, (err, topic) => {
    if (err) return next(err);
    if (topic) {
      res.status(400).json({ error: "That topic is taken. Try another." });
    } else next();
  });
};

// Create new topic
router.post(
  "/upload",
  authTokenMiddleware,
  authAdminMiddleware,
  checkTopicExists,
  (req, res, next) => {
    Topic.create(req.body, (err, topic) => {
      if (err) return next(err);
      res.status(201).json({ ...topic.toJSON() });
    });
  }
);

router
  .route("/:id")
  .get(authTokenMiddleware, async (req, res) => {
    try {
      const { username, role } = jwt.decode(req.token);
      if (["admin", "marketing manager"].includes(role)) {
        const topic = await Topic.findById(req.params.id).populate(
          "contributions"
        );
        topic
          ? res.status(200).json({ ...topic.toJSON() })
          : res.sendStatus(404);
      } else if (["marketing coordinator", "student", "guest"].includes(role)) {
        const user = await User.findOne({ username });
        const topic = await Topic.findById(req.params.id);
        if (user.faculty === topic.faculty) {
          topic
            ? res.status(200).json({ ...topic.toJSON() })
            : res.sendStatus(404);
        } else res.sendStatus(403);
      } else res.sendStatus(403);
    } catch (err) {
      next(err);
    }
  })
  .put(authTokenMiddleware, authAdminMiddleware, (req, res, next) => {
    if ("faculty" in req.body) throw new Error("Faculty is non-editable");
    Topic.findByIdAndUpdate(req.params.id, req.body, (err, topic) => {
      if (err) return next(err);
      res.status(200).json({ topic });
    });
  })
  .delete(authTokenMiddleware, authAdminMiddleware, (req, res, next) => {
    Topic.findByIdAndDelete(req.params.id, (err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

router.get(
  "/byFaculty/:faculty",
  authTokenMiddleware,
  async (req, res, next) => {
    const { faculty } = req.params;
    const { username } = jwt.decode(req.token);
    const user = await User.findOne({ username });
    if (
      ["admin", "marketing manager"].includes(user.role) ||
      (user.role === "marketing coordinator" && user.faculty === faculty)
    ) {
      next();
    } else res.sendStatus(403);
  },
  (req, res, next) => {
    Topic.find({ faculty: req.params.faculty })
      .populate("contributions")
      .exec((err, topics) => {
        if (err) return next(err);
        res.status(200).json({ topics });
      });
  }
);

router.get("/statisticsByYear/:year", async (req, res, next) => {
  try {
    const topics = await Topic.find({ year: req.params.year }).populate(
      "contributions"
    );
    const contributionsPerFaculty = await Topic.aggregate([
      { $match: { year: parseInt(req.params.year) } },
      // {
      //   $lookup: {
      //     from: "contributions",
      //     let: { contributions: "$contributions" },
      //     pipeline: [
      //       { $match: { $expr: { $in: ["$_id", "$$contributions"]}}},
      //       { $lookup: {
      //         from: "users"
      //       }}
      //     ]
      //   },
      // },
      {
        $group: {
          _id: "$faculty",
          total: { $sum: 1 },
          isSelected: {
            $sum: {
              $cond: { if: { $eq: ["$isSelected", true] }, then: 1, else: 0 },
            },
          },
        },
      },
    ]);
    res.status(200).json({ contributionsPerFaculty });
    // res.status(200).json({ topics, contributionsPerFaculty });
  } catch (err) {
    next(err);
  }
});

router.use((err, req, res, next) => {
  res.status(400).json({ error: err.message });
});

module.exports = router;
