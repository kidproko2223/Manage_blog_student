import ApiService from "./Api";

const BASE_URL = process.env.URL || "http://localhost:3001/api/v1";
const client = new ApiService({ baseURL: BASE_URL });

const userAPI = {};

userAPI.login = (username, password) => {
  return client.post(`/users/login`, {
    username,
    password
  });
};

userAPI.addUser = (username, password, role, token) => {
  return client.post(
    `/users/signup`,
    {
      username,
      password,
      role,
    },
    {
      headers: {
        authorization: `Bearer ${token}`,
      },
    }
  );
};

userAPI.getUser = (username, token) => {
  return client.get(`/users/${username}`, {
    headers: {
      authorization: `Bearer ${token}`,
    },
  });
};

userAPI.updateUser = (username, password, role, token) => {
  return client.put(
    `/users/${username}`,
    {
      username,
      password,
      role,
    },
    {
      headers: {
        authorization: `Bearer ${token}`,
      },
    }
  );
};

userAPI.deleteUser = (username, token) => {
  return client.delete(`/users/${username}`, {
    headers: {
      authorization: `Bearer ${token}`,
    },
  });
};

// const PAGE_LIMIT = 20;
// const getPageSlice = (limit, page = 0) => ({ begin: page * limit, end: (page + 1) * limit });
// const getPageValues = ({ begin, end, items }) => items.slice(begin, end);

// baseAPI.getTopStoryIds = () => client.get(`/topstories${JSON_QUERY}`);
// baseAPI.getStory = id => client.get(`/item/${id}${JSON_QUERY}`);
// baseAPI.getStoriesByPage = (ids, page) => {
//   const { begin, end } = getPageSlice(PAGE_LIMIT, page);
//   const activeIds = getPageValues({ begin, end, items: ids });
//   const storyPromises = activeIds.map(id => MothraApi.getStory(id));
//   return Promise.all(storyPromises);
// };

export default userAPI;
