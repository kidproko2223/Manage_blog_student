import ApiService from "./Api";

const BASE_URL = process.env.URL || "http://localhost:3001/api/v1";
const client = new ApiService({ baseURL: BASE_URL });
const topicAPI = {};

topicAPI.getStatistics = (year, token) => {
  return client.get(`/topics/statisticsByYear/${year}`, {
    headers: { authorization: `Bearer ${token}` },
  });
};

topicAPI.createTopic = (
  title,
  description,
  faculty,
  closureDate,
  finalClosureDate,
  token
) => {
  return client.post(
    `/topics`,
    { title, description, faculty, closureDate, finalClosureDate },
    { headers: { authorization: `Bearer ${token}` } }
  );
};

topicAPI.getTopicById = (id, token) => {
  return client.get(`/topics/${id}`, {
    headers: { authorization: `Bearer ${token}` },
  });
};

topicAPI.getTopicsByFaculty = (faculty, token) => {
  return client.get(`/topics/byFaculty/${faculty}`, {
    headers: { authorization: `Bearer ${token}` },
  });
};

topicAPI.updateTopicById = (id, update, token) => {
  return client.put(`/topics/${id}`, update, {
    headers: { authorization: `Bearer ${token}` },
  });
};

topicAPI.deleteTopic = (id, token) => {
  return client.delete(`/topics/${id}`, {
    headers: { authorization: `Bearer ${token}` },
  });
};

export default topicAPI;
