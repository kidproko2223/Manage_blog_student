import React from "react";
import { Switch, Route, Redirect, useRouteMatch } from "react-router-dom";
import Login from "./Login";
import Signup from "./Signup";

const User = () => {
  const match = useRouteMatch();
  return (
    <Switch>
      <Route path={`${match.path}/login`} component={Login} />
      <Route path={`${match.path}/signup`} component={Signup} />
      <Redirect to={`${match.path}/login`} component={Login} />
    </Switch>
  );
};

export default User;
