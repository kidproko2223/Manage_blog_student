import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { Form, Input, Button, Checkbox, Layout } from "antd";
import userAPI from "services/userAPI";
import {
  UserOutlined,
  LockOutlined,
  GoogleCircleFilled,
  FacebookFilled,
  AppleFilled,
} from "@ant-design/icons";
import globalStyles from "antd/dist/antd.css";
import styles from "./login.module.css";
import FooterComponent from "../../components/Footer";
import cx from "classnames";
import { saveToken } from "../../redux/userSlice";

const { Content, Footer } = Layout;

const Login = () => {
  const [username, setUsername] = useState(null);
  const [password, setPassword] = useState(null);
  const onFinish = (values) => {
    console.log("Success:", values);
  };
  const dispatch = useDispatch();

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(username, password);
    try {
      const res = await userAPI.login(username, password);
      const action = saveToken(res);
      dispatch(action);
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <Layout>
      <Content className={styles.login}>
        <Form
          name="normal_login"
          className={styles.login_form}
          initialValues={{
            remember: true,
          }}
          onFinish={onFinish}
        >
          <h1>Mothra</h1>
          <Form.Item
            name="username"
            rules={[
              {
                required: true,
                message: "Please input your Username!",
              },
            ]}
          >
            <Input
              prefix={<UserOutlined className="site-form-item-icon" />}
              placeholder="Username"
              onChange={(val) => {
                const currentVal = val.target.value;
                setUsername(currentVal);
              }}
            />
          </Form.Item>
          <Form.Item
            name="password"
            rules={[
              {
                required: true,
                message: "Please input your Password!",
              },
            ]}
          >
            <Input
              prefix={<LockOutlined className="site-form-item-icon" />}
              type="password"
              placeholder="Password"
              onChange={(val) => {
                const currentVal = val.target.value;
                setPassword(currentVal);
              }}
            />
          </Form.Item>
          <Form.Item>
            <span
              className={cx(
                styles.login_replace_left,
                globalStyles["replace-checkbox"]
              )}
            >
              <Form.Item name="remember" valuePropName="checked" noStyle>
                <Checkbox>Remember me</Checkbox>
              </Form.Item>
            </span>

            <a
              className={cx(
                styles.login_replace_right,
                globalStyles["login-form-forgot"]
              )}
              href=""
            >
              Forgot password?
            </a>
          </Form.Item>
          <Form.Item>
            Login with:
            <GoogleCircleFilled className={styles.icon} />
            <FacebookFilled className={styles.icon} />
            <AppleFilled className={styles.icon} />
          </Form.Item>

          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              className={cx(
                styles.login_replace_button,
                globalStyles["login-form-button"]
              )}
              onClick={handleSubmit}
            >
              Log in
            </Button>
          </Form.Item>
        </Form>
      </Content>
      <Footer>
        <FooterComponent></FooterComponent>
      </Footer>
    </Layout>
  );
};

export default Login;
