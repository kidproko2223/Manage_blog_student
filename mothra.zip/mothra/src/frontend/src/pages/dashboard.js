import React, { useState } from "react";
import styles from "./dashboard.module.css";
import PageLayout from "../components/BasicLayout";
import {Table,Input, Button, Tooltip, Space,} from 'antd';
import { 
    DeleteOutlined,
    SnippetsOutlined,
    UserAddOutlined
} from '@ant-design/icons';
const data = [
  {
    key: '1',
    name: 'John Brown',
    age: 32,
    role: 'Marketing Coordinator',
    faculty: 'Science',
  },
  {
    key: '2',
    name: 'Jim Green',
    age: 42,
    role: 'Marketing Manager',
    faculty: 'Science',
  },
  {
    key: '3',
    name: 'Joe Black',
    age: 32,
    role: 'Marketing Coordinator',
    faculty: 'Engineering',
  },
  {
    key: '4',
    name: 'Jim Red',
    age: 32,
    role: 'Marketing Coordinator',
    faculty: 'Law',
  },
  
];
  
function onChange(pagination, filters, sorter, extra) {
  console.log('params', pagination, filters, sorter, extra);
}

const Dashboard = () => {
  const [dataSource, setDataSource] = useState(data);
  const [value, setValue] = useState('');
  //delete user data function
  let deleteUser = (key) => {
    const deletedData = data.filter( userdata => {
      return userdata.key !== key
    });
    setDataSource(deletedData);

  }
  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      sorter: (a, b) => a.name.length - b.name.length,
      sortDirections: ['descend'],
    },
    {
      title: 'Age',
      dataIndex: 'age',
      defaultSortOrder: 'descend',
      sorter: (a, b) => a.age - b.age,
      responsive: ['md'],
    },
    {
      title: 'Role',
      dataIndex: 'role',
      responsive: ['md'],
      filters: [
        {
          text: 'Marketing Manager',
          value: 'Marketing Manager',
        },
        {
          text: 'Marketing Coordinator',
          value: 'Marketing Coordinator',
        },
      ],
      filterMultiple: false,
      // specify the condition of filtering result
      // here is that finding the name started with `value`
      onFilter: (value, record) => record.role.indexOf(value) === 0,
      sorter: (a, b) => a.role.length - b.role.length,
      sortDirections: ['descend', 'ascend'],

    },
    {
      title: 'Faculty',
      dataIndex: 'faculty',
      responsive: ['lg'],
      filters: [
        {
          text: 'Law',
          value: 'Law',
        },
        {
          text: 'Engineering',
          value: 'Engineering',
        },
        {
          text: 'Science',
          value: 'Science',
        }, {
          text: 'Information technology',
          value: 'Information technology',
        },
      ],
      filterMultiple: false,
      onFilter: (value, record) => record.faculty.indexOf(value) === 0,
      sorter: (a, b) => a.faculty.length - b.faculty.length,
      sortDirections: ['descend', 'ascend'],
    },
    {
      title: '',
      key: 'action',
      render: (data) => (
        <Space size="middle">
          <Button>
          <SnippetsOutlined />
          </Button>
          |
          <Button type="primary" danger onClick={() => deleteUser(data.key)}>
          <DeleteOutlined />
          </Button>
        </Space>
      ),
    },
  ];
  const firstContent = (
    <div className={styles.site_layout_background} style={{ padding: 24 }}>
        <p className={styles.title}>Administrator accounts</p>
    </div>
  );
  const secondContent = (
    <div className={styles.site_layout_background} style={{ padding: 24 }}>
          <Space direction="vertical" style={{ width: '100%' }}>
          <Input
            placeholder="Search Name"
            style={{ width: '100%' }}
            value={value}
            onChange={e => {
              const currValue = e.target.value;
              setValue(currValue);
              const filteredData = data.filter(entry =>
                entry.name.includes(currValue)
              );
              setDataSource(filteredData);
            }}
          />
          <Table columns={columns} dataSource={dataSource} onChange={onChange}/>
        </Space>
        <Tooltip title="add user">
          <Button type="primary" shape="circle" icon={<UserAddOutlined style={{fontSize: '30px'}}  />} 
            style = {{
              zIndex: 1, 
              position: 'fixed', 
              right: 30, 
              bottom: 40, 
              width: 60, 
              height: 60,
              backgroundColor: '#002140',
              border: 'none'

            }}  
          />
        </Tooltip>
    </div>
  );
  return (
    <PageLayout pageContentHeader = {firstContent} pageContent = {secondContent}>
    </PageLayout>
  )
};

export default Dashboard;

