import React from "react";
import styles from "./dashboard.module.css";
import PageLayout from "../components/BasicLayout";
import {Input, Button, Tooltip, Space, Form, Select, DatePicker } from 'antd';
import { EditOutlined } from '@ant-design/icons';
import moment from 'moment';

const data = 
  {
    key: '1',
    firstName: 'Jim',
    lastName: 'Cook',
    dateOfBirth: '2014/02/09',
    phone: '012345789',
    mail: 'abc@gmail.com',
    role: 'mm',
    faculty: 'Law',
    avatar: 'https://firebasestorage.googleapis.com/v0/b/instik-image.appspot.com/o/user_avatar%2FArashiyama%2C%20Japan%201920x1080.jpg?alt=media&token=25f909cc-82da-4e16-bab7-bdb233f8f1c1',
  }
  
const ProfileDetail = () => {
  const dateFormat = 'DD/MM/YYYY';
  let updateInfo = (e) => {
    if(e){
      e.preventDefault();
      console.log(data);
    }
  };
  
  const firstContent = (
    <div className={styles.site_layout_background} style={{ padding: 24 }}>
        <p className={styles.title}>{data.firstName} {data.lastName}'s Profile</p>
    </div>
  );
  
  const secondContent = (
    <div className={styles.site_layout_background} style={{ padding: 24 }}>
      <p className={styles.title}>{data.firstName} {data.lastName}'s Profile</p>
      <div style={{
        backgroundColor: 'black',
        height: 2,
        marginBottom: 20,
        width: '50%'          
      }}>
      </div>
      <Space size="large">
        <Form
          labelCol={{ span: 8 }}
          wrapperCol={{ span: 16 }}
          layout="horizontal"
          size='middle'
          style={{
            width: "100%"
          }}
        >
          <Form.Item label="First Name"
            rules={[
              {
                required: true,
                message: 'Please input first name!',
              },
            ]}
          >
            <Input defaultValue={data.firstName}
              onChange={val => 
                {
                  if(val){
                    const currentVal = val.target.value
                    data.firstName = currentVal;
                  }
                }
              }
            />
          </Form.Item>
          <Form.Item label="Last Name"
            rules={[
              {
                required: true,
                message: 'Please input last name!',
              },
            ]}
          >
            <Input defaultValue={data.lastName}
              onChange={val => 
                {
                  if(val){
                    const currentVal = val.target.value
                    data.lastName = currentVal;
                  }
                }
              }
            />
          </Form.Item>
          <Form.Item label="Date of birth"
          rules={[
            {
              type: 'date',
              required: true,
              message: 'Please select date of birth!',
            },
          ]}
        >
            <DatePicker defaultValue={moment(data.dateOfBirth, dateFormat)} format={dateFormat}
              onChange = {
                val => 
                {
                  if(val){
                    data.dateOfBirth = val.format('L')
                 }
                }
              }
            />
          </Form.Item>
          <Form.Item label="Role"
            rules={[
              {
                type: 'array',
                required: true,
                message: 'Please select role!',
              },
            ]}
          >
            <Select defaultValue={data.role}
              onChange = { val => 
                {
                  if(val){
                    const currentVal = val.target.value
                    data.role = currentVal;
                  }
                }
              }
            >
              <Select.Option value="mm">Marketing manager</Select.Option>
              <Select.Option value="mc">Marketing coordinator</Select.Option>
              <Select.Option value="student">Student</Select.Option>
            </Select>
          </Form.Item>
          <Form.Item label="Phone" 
            rules={[{ 
              type: 'number',
              required: true,
              message: 'Please input phone number!',
            }]}
          >
            <Input defaultValue={data.phone} 
              onChange={val => 
                {
                  if(val){
                    const currentVal = val.target.value
                    data.phone = currentVal;
                  }
                }
              }
            />
          </Form.Item>
          <Form.Item label="Email" rules={[
            {
              type: 'email',
              message: 'The input is not valid E-mail!',
            },
            {
              required: true,
              message: 'Please input E-mail!',
            },
          ]}
          >
            <Input defaultValue={data.mail}
              onChange={val => 
                {
                  if(val){
                    const currentVal = val.target.value
                    data.mail = currentVal;
                  }
                }
              }
            />
          </Form.Item>
          <Form.Item>
            <Button onClick={updateInfo} 
              style={{
                marginLeft: 100
              }}
            >
              Update
            </Button>
          </Form.Item>
        </Form>             
      </Space>
      <Tooltip title="add user">
          <Button type="primary" shape="circle" icon={<EditOutlined style={{fontSize: '30px'}}  />} 
          style = {{
            zIndex: 1, 
            position: 'fixed', 
            right: 30, 
            bottom: 40, 
            width: 60, 
            height: 60,
            backgroundColor: '#002140',
            border: 'none'

        }} />
        </Tooltip>
    </div>
  );
  return (
    <PageLayout pageContentHeader = {firstContent} pageContent = {secondContent}>
    </PageLayout>
  )
};

export default ProfileDetail;
