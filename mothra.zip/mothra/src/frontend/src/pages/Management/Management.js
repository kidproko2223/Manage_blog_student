import React, { useState } from "react";
import {
  Input,
  Space,
  List,
  Tag,
  Divider,
  Checkbox,
  Button,
  Radio,
  Card,
} from "antd";
import {
  DownloadOutlined,
  MessageOutlined,
  RightOutlined,
} from "@ant-design/icons";
import styles from "./Management.module.css";
import BasicLayout from "../../components/BasicLayout";

const { CheckableTag } = Tag;

const { Meta } = Card;

const tagsData = ["Science", "Law", "Marketing", "IT"];

const listData = [];

const checkedArr = [];

const selectedAll = [];

const topicAvailable = [];

const userRole = "DD";

for (let i = 0; i < 10; i++) {
  listData.push({
    href: "https://ant.design",
    title: `ant design part ${i}`,
    avatar: "https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png",
    description:
      "Ant Design, a design language for background applications, is refined by Ant UED Team.",
    content:
      "We supply a series of design principles, practical patterns and high quality design resources (Sketch and Axure), to help people create their product prototypes beautifully and efficiently.",
    faculty: "Marketing",
    isChecked: false,
  });
}

for (let i = 0; i < 4; i++) {
  topicAvailable.push({
    href: "https://ant.design",
    title: `Topic ${i}`,
    deadLine: "09/02/2021",
  });
}

const IconText = ({ icon, text }) => (
  <Space>
    {React.createElement(icon)}
    {text}
  </Space>
);

const FacultyRadio = () => (
  <Radio.Group defaultValue="Science" buttonStyle="solid" size="middle">
    {tagsData.map((tag) => (
      <Radio.Button
        key={tag}
        value={tag}
        style={{
          width: 100,
          borderRadius: 0,
          textAlign: "center",
        }}
      >
        {tag}
      </Radio.Button>
    ))}
  </Radio.Group>
);

const TopicAvailable = () => (
  <div style={{ width: "100%" }}>
    {topicAvailable.map((topic) => (
      <Card
        key={topicAvailable.indexOf(topic)}
        className={styles.topicCard}
        actions={[
          <Button
            type="primary"
            shape="round"
            size="middle"
            style={{
              float: "right",
              marginRight: 3,
            }}
          >
            View <RightOutlined />
          </Button>,
        ]}
      >
        <Meta title={topic.title} description={"Deadline: " + topic.deadLine} />
      </Card>
    ))}
  </div>
);

const FacultyManagement = () => {
  const [dataSource, setDataSource] = useState(listData);
  const [selectedTags, setSelectedTag] = useState(["Marketing"]);
  const [value, setValue] = useState("");
  let handleChange = (tag, chose) => {
    const nextSelectedTags = chose
      ? [...selectedTags, tag]
      : selectedTags.filter((t) => t !== tag);
    setSelectedTag(nextSelectedTags);
    const filteredData = listData.filter((d) =>
      nextSelectedTags.includes(d.faculty)
    );
    setDataSource(filteredData);
  };
  let onDownloadAll = () => {
    listData.forEach((item) => selectedAll.push(item.title));
    console.log(selectedAll);
  };
  let onCheck = (item) => {
    item.isChecked = !item.isChecked;
    console.log(item.isChecked);
    if (item.isChecked === true) {
      checkedArr.push(item.title);
      console.log(checkedArr);
    }
  };

  const pageContent = (
    <div className={styles.site_layout_background} style={{ padding: 24 }}>
      <div className={styles.site_layout_background} style={{ padding: 24 }}>
        {userRole == "DD" ? <FacultyRadio /> : null}
        <p className={styles.title}>Contributions</p>
        <Divider />
        Filter by topic:
        {tagsData.map((tag) => (
          <CheckableTag
            key={tag}
            checked={selectedTags.indexOf(tag) > -1}
            onChange={(checked) => handleChange(tag, checked)}
            style={{ marginLeft: "1em" }}
          >
            {tag}
          </CheckableTag>
        ))}
        <Divider />
        <Input
          placeholder="Search by title"
          style={{ width: "22em" }}
          value={value}
          onChange={(e) => {
            const currValue = e.target.value;
            setValue(currValue);
            const filteredData = listData.filter((entry) =>
              entry.title.includes(currValue)
            );
            setDataSource(filteredData);
          }}
        />
        <Divider />
        {userRole == "DM" ? <TopicAvailable /> : null}
      </div>
      <Divider />
      <Space direction="vertical" style={{ width: "100%" }}>
        <Button
          type="primary"
          shape="round"
          icon={<DownloadOutlined />}
          size="middle"
          style={{
            width: 170,
            float: "right",
          }}
          onClick={onDownloadAll}
        >
          <p
            style={{
              display: "inline-block",
              marginLeft: 5,
            }}
          >
            Download all ({listData.length})
          </p>
        </Button>
        <List
          itemLayout="vertical"
          size="large"
          pagination={{
            onChange: (page) => {
              console.log(page);
            },
            pageSize: 3,
          }}
          dataSource={dataSource}
          footer={
            <div>
              <b>Mothra</b> Contributions list
            </div>
          }
          renderItem={(item) => (
            <List.Item
              key={item.title}
              actions={[
                <IconText
                  icon={MessageOutlined}
                  text="2"
                  key="list-vertical-message"
                />,
                <IconText icon={DownloadOutlined} key="list-vertical-like-o" />,
              ]}
            >
              <Space direction="vertical">
                <Checkbox onChange={() => onCheck(item)} />
                <Tag color="blue">{item.faculty}</Tag>
              </Space>
              <List.Item.Meta
                title={<a href={item.href}>{item.title}</a>}
                description={item.description}
              />
              {item.content}
            </List.Item>
          )}
        />
      </Space>
    </div>
  );
  return <BasicLayout pageContent={pageContent}></BasicLayout>;
};

export default FacultyManagement;
