import React from "react";

const LandingPage = () => {
  return (
    <div>LandingPage</div>
  )
}

export default LandingPage;