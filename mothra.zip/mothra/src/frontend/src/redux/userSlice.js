import { createSlice } from "@reduxjs/toolkit";

const getInitialState = () => ({
  username: "",
  accessToken: "",
  refreshToken: "",
  role: "",
  userAvatar: "",
  isAuthenticated: false,
  isFetching: false,
  isSubmiting: false,
  error: "",
});

const userSlice = createSlice({
  name: "user",
  initialState: getInitialState(),
  reducers: {
    saveToken(state, action) {
      const {accessToken, refreshToken} = action.payload;
      state.accessToken = accessToken;
      state.refreshToken = refreshToken;
    },
    baseRequest(state, action) {
      state.isFetching = true;
    },
    baseFailure(state, action) {
      state.error = action.payload.error;
    },
  },
});

export const { saveToken, baseRequest, baseFailure } = userSlice.actions;
export default userSlice.reducer;
