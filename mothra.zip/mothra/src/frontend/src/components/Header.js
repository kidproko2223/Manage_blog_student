import { Layout } from "antd";

const { Header } = Layout;

const PageHeader = () => {
  return <Header>Header</Header>;
};

export default PageHeader;
