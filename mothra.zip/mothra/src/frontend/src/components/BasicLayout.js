import React, { useState, useLayoutEffect } from "react";
import { Layout, Menu, Avatar, Space, Dropdown } from "antd";
import {
  UserOutlined,
  UploadOutlined,
  VideoCameraOutlined,
  DownOutlined,
  SettingOutlined,
  LogoutOutlined,
} from "@ant-design/icons";
const { Header, Sider, Content, Footer } = Layout;

const BasicLayout = (props) => {
  //Header: user dropdown menu
  const menu = (
    <Menu>
      <Menu.Item>
        <a
          target="_blank"
          rel="noopener noreferrer"
          href="http://www.alipay.com/"
        >
          <UserOutlined />
          Profile
        </a>
      </Menu.Item>
      <Menu.Item>
        <a
          target="_blank"
          rel="noopener noreferrer"
          href="http://www.taobao.com/"
        >
          <SettingOutlined /> Setting
        </a>
      </Menu.Item>
      <Menu.Item danger>
        <a
          target="_blank"
          rel="noopener noreferrer"
          href="http://www.taobao.com/"
        >
          <LogoutOutlined /> Log out
        </a>
      </Menu.Item>
    </Menu>
  );

  const useWindowWidth = () => {
    const [width, setWidth] = useState(0);
    useLayoutEffect(() => {
      function updateWidth() {
        setWidth([window.innerWidth]);
      }
      window.addEventListener("resize", updateWidth);
      updateWidth();
      return () => window.removeEventListener("resize", updateWidth);
    }, []);
    return width;
  };

  const deviceWidth = useWindowWidth() > 576 ? "80" : "0";

  //Hook for collapsed menu
  const [isCollapse, setCollapse] = useState(true);
  let toggleMenu = () => {
    setCollapse(!isCollapse);
  };

  const contentStyle =
    useWindowWidth() > 576
      ? { margin: "24px 16px 0 90px", overflow: "initial" }
      : { margin: "24px 16px 0", overflow: "initial" };
  return (
    <Layout>
      {/* Right-side */}
      <Sider
        collapsedWidth={deviceWidth}
        collapsible
        collapsed={isCollapse}
        onCollapse={toggleMenu}
        style={{
          height: "100vh",
          position: "fixed",
          zIndex: 999,
        }}
      >
        <div
          style={{
            height: 32,
            margin: 16,
            color: "white",
            textAlign: "center",
            fontSize: 25,
            fontWeight: 900,
          }}
        >
          {isCollapse ? "M" : "Mothra"}
        </div>
        {/* Menu */}
        <Menu theme="dark" mode="inline" defaultSelectedKeys={["4"]}>
          <Menu.Item key="1" icon={<UserOutlined />}>
            nav 1
          </Menu.Item>
          <Menu.Item key="2" icon={<VideoCameraOutlined />}>
            nav 2
          </Menu.Item>
          <Menu.Item key="3" icon={<UploadOutlined />}>
            nav 3
          </Menu.Item>
        </Menu>
      </Sider>
      {/* Left-side */}
      <Layout className="site-layout">
        <Header style={{ padding: 0, background: "#fff" }}>
          <div
            style={{
              float: "right",
              marginRight: 20,
            }}
          >
            <Space size={"middle"}>
              <Avatar size={30} icon={<UserOutlined />} />
              <p
                style={{
                  marginBottom: 0,
                  fontFamily: "Helvetica",
                  color: "#002140",
                  fontSize: "1em",
                  fontWeight: 600,
                }}
              >
                Admin
              </p>
              <Dropdown overlay={menu}>
                <a
                  className="ant-dropdown-link"
                  onClick={(e) => e.preventDefault()}
                >
                  <DownOutlined style={{ color: "#002140" }} />
                </a>
              </Dropdown>
            </Space>
          </div>
        </Header>
        {/* Change content here */}
        <Content style={contentStyle}>{props.children}</Content>
        <Footer style={{ textAlign: "center" }}>
          Mothra ©2021 Created by Mothra team
        </Footer>
      </Layout>
    </Layout>
  );
};

export default BasicLayout;
