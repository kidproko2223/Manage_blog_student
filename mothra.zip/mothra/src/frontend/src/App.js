import "./App.css";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/User/Login";
import Dashboard from "./pages/dashboard"
import NoFoundPage from "./pages/404";
import NoAuthorizedPage from "./pages/403";
import ProfileDetail from "./pages/ProfileDetail"
import ContributionManagement from "./pages/Management/Management"


function App() {
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/home" component={Home} />
          <Route path="/login" component={Login} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/profile-detail" component={ProfileDetail} />
          <Route path="/management" component={ContributionManagement} />
          <Route path="/403" component={NoAuthorizedPage} />
          <Route path="/404" component={NoFoundPage} />
          <Redirect to="/404" />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
